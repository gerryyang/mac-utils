-module(ops).
-export([add/2]).

add(A,B) -> A + B.
